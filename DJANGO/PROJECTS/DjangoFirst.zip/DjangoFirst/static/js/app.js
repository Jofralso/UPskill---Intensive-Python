setTimeout(() => {
    alert('Welcome to my site!');
}, 3000);
